package com.amrita.jpl.cys21003.p1;

import java.util.Scanner;

public class p1 {
    /**
     * This class demonstrates the periodical lab exam.
     *
     *
     * @author Aishwarya G
     * @version 1.0
     */
    int number;

    /**
     * function to factorial of a number
     * @param number
     */
    public void fact(int number) {
        int fact=1;
        for(int i=1;i<=number;i++){
            fact=fact*i;
        }
        System.out.println("Factorial of "+number+" is: "+fact);
    }

    /**
     * function to find fibonacci series
     * @param number
     */
    public void fibo(int number) {
        int f1 = 0, f2 = 1, f3,i;
        System.out.print(f1 + " " + f2);//printing 0 and 1

        for (i = 2; i < number; ++i)//loop starts from 2 because 0 and 1 are already printed
        {
            f3 = f1 + f2;
            System.out.print(" " + f3);
            f1 = f2;
            f2 = f3;
        }
    }

    /**
     * function to find prime no.
     * @param number
     */
    public void prime_test(int number) {
        int i,m=0,flag=0;

        m=number/2;
        if(number==0||number==1){
            System.out.println(number+" is not prime number");
        }else{
            for(i=2;i<=m;i++){
                if(number%i==0){
                    System.out.println(number+" is not prime number");
                    flag=1;
                    break;
                }
            }
            if(flag==0)  { System.out.println(number+" is prime number"); }
        }
    }

    /**
     * function to find sum of n number
     * @param number
     */
    public void sum_n_no(int number) {
        int sum = 0;

        for(int i = 1; i <= number; ++i)
        {

            sum = sum + i;
        }

        System.out.println("Sum of First 10 Natural Numbers is = " + sum);
    }

    public static void main(String[] args) {

        p1 a = new p1();
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an choice: ");
        int choice = input.nextInt();

        a.number=5;


        switch (choice) {
            case 1:
                a.fact(a.number);
                break;
            case 2:
                a.fibo(a.number);
                break;
            case 3:
                a.sum_n_no(a.number);
                break;
            case 4:
                a.prime_test(a.number);
                break;
        }
        input.close();
    }
}

